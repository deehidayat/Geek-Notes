## Employee Directory ##

### Sample Application built with Backbone.js and Ratchet ###

"Backbone Directory" is a simple Employee Directory application built with [Backbone.js](http://backbonejs.org) and [Ratchet] (http://maker.github.io/ratchet/).

Refer to [this blog post](http://coenraets.org) for more information about the application.

The application runs out-of-the-box with an in-memory data store.
