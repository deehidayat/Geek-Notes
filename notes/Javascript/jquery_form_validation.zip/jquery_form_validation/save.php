<?php
header('Content-type: text/xml');
echo "<?xml version=\"1.0\"?>\n";
echo "<response>\n";
echo "\t<status>1</status>\n";
echo "</response>";
?>