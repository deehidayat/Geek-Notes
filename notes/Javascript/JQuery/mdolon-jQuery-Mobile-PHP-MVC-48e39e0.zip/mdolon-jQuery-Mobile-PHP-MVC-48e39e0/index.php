<?php

/*****************************************************
  Simple jQuery Mobile MVC Framework in PHP
  =========================================
  Read more at:
  http://devgrow.com/jquery-mobile-php-mvc-framework/

  This is meant to serve as a simple basis for
  more complex jQuery Mobile applications that
  can benefit from an MVC architecture.
*****************************************************/

require_once('lib/config.php');
$app = new App;