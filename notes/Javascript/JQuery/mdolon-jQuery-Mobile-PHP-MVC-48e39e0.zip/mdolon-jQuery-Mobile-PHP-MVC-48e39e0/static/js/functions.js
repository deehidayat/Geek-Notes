$(document).ready(function() {        
	// Enter necessary functions here
});