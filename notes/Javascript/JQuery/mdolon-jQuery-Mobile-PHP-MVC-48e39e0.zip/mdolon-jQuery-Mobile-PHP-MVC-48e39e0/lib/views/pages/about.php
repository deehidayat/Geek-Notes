
	<h2>About <?PHP echo APP_NAME; ?></h2>

	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin euismod nulla non sem varius at semper libero malesuada.</p>
	
	<p>Duis laoreet nibh non leo fringilla luctus. Nam vitae arcu purus, ut facilisis elit. Vivamus at purus metus, ut venenatis nisi. Sed sed sem tortor. Mauris et pellentesque odio. Phasellus sit amet velit fringilla nibh dapibus tincidunt non at metus. Integer feugiat arcu elit. Donec at elementum elit. Cras faucibus ligula a erat egestas ut volutpat neque convallis. Pellentesque pretium libero in velit suscipit in mollis orci posuere. Donec velit magna, ultrices eu tincidunt sit amet, lacinia non quam.</p>
	
	<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam erat volutpat. Sed viverra, nisi in rhoncus varius, diam tellus placerat magna, ac pharetra quam massa tempor arcu. Mauris accumsan eros non orci lacinia laoreet. Pellentesque pretium tempor tempus.</p>