
	<h2>Register</h2>
	<form action='' method='post' class='register-form'>
		<p>
			<label for='name'>Name:</label>
			<input type='text' name='name' class='text' id='name' value='' />
		</p>
		<p>
			<label for='email'>E-mail Address:</label>
			<input type='text' name='email' class='text' id='email' value='' />
		</p>
		<p>
			<label for='password'>Password:</label>
			<input type='password' name='password' class='text' id='password' />
		</p>
		<p>
			<label for='password2'>Confirm Password:</label>
			<input type='password' name='password2' class='text' id='password2' />
		</p>
		<p>
			<label></label>
			<input type='submit' data-icon='check' class='button contact' value='Register' />
		</p>
	</form>