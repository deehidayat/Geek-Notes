
	<h2>Authentication Error</h2>
	
	<p>You must be logged in or an administrator to access this content.  Please <a href="./user">login</a> and try again.</p>