	
	<div class="content left page">
		<h1>404 Error</h1>
		<p>Sorry, we couldn't find that page. Please check the URL or try again later.</p>
	</div>