	</div>
	<div data-role="footer" data-position="fixed">
		<p class="left p10">&copy; 2010 <?PHP echo APP_NAME; ?></p>
		<ul class="right simplenav p10">
			<li><a href="./about" data-icon="info" class="ui-btn-right">About</a></li>
			<li><a href="./terms" data-icon="add">Terms of Service</a></li>
		</ul>
	</div>

</div>
</body>
</html>