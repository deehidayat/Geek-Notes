1st JavaScript Editor Pro
version  : 5.1
author   : Yaldex Software
www      : http://www.yaldex.com
contacts : http://www.yaldex.com/help.htm

Compatibility:
Any windows
 

Installation :
--------------
Unzip �fjse.exe� file into any directory, 
then double-click extracted file to install 1st JavaScript Editor.

