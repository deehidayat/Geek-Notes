To use this class, you must first have ffmpeg2theora application. If you don't already have it, you can download it for free from http://v2v.cc/~j/ffmpeg2theora/download.html.

Place ffmpeg2theora.exe file in a folder with this class file. Done!