<?php

/* 
this example is used to convert any video file to *.ogv file and convert any audio file to *.oga file using htmlL5_video_audio_converter.class.php, especially for Windows users
author: usman didi khamdani
author's email: usmankhamdani@gmail.com
author's phone: +6287883919293
*/  

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
Source File <input type="file" name="fupload" /> <input type="submit" name="upload" value="convert" />
</form>
<hr />

<?php

if(isset($_POST['upload'])) {
	include('htmlL5_video_audio_converter.class.php');
	$HTML5VideoAudio = new HTML5VideoAudio;

	$uploaded_file = $_FILES['fupload'];

	//echo $HTML5VideoAudio->Converter($uploaded_file,1024); // max. size of file which will be converted is 1024 KB or 1 MB
	//echo $HTML5VideoAudio->Converter($uploaded_file); // default max. size of file which will be converted 
	echo $HTML5VideoAudio->Converter($uploaded_file,0); // unlimitted max. size uploaded file
}

?>