<?php  
   require_once('w3v.php'); 
   //this example loads every video on video directory
   $d = dir("video/");
   $idx=0;
   while (false !== ($entry = $d->read())) {
     if($entry!='.'&&$entry!='..') {
       $w3v[]=new w3v('video'.$idx,$d->path.$entry); 
       $idx++;
     }
   }
   $d->close()
?>
<html>
<body>
   <h1>This is an example of w3v library, it loads every file on video directory</h1>
     <?php for($i=0;$i<count($w3v);$i++) { ?>
   <div>
    <?=$w3v[$i]->display();?>
   </div>
    <?php } ?>
</body>
 <?php for($i=0;$i<count($w3v);$i++)echo $w3v[$i]->getScript(); ?>
<script type="text/javascript">
     <?php for($i=0;$i<count($w3v);$i++)echo $w3v[$i]->load(); ?>
</script>
</html>