<?php
class w3v {
  protected $ext=null;
  protected $file=null;
  protected $type=null;
  protected $id=null;
  
  //defaults go here
  private $width=224;
  private $height=140;
  private $previewImage='videoplayer.jpg';

  public function __construct($id,$file,$width=false,$height=false) {
    //first of all i check wether it's a youtube video
    if($width)$this->width=$width;
    if($height)$this->height=$height;
    switch(substr($file,0,15)) {
    case 'http://www.yout':case 'http://youtu.be':
      $this->type=noDivxVideo::init($this->previewImage,$this->width,$this->height);
      break;
    default:
     $lastDot=strrpos($file,'.');
     $this->ext=substr($file,$lastDot+1);
     switch($this->ext) {
     case 'mp4':case 'mov':case 'f4v':case 'flv':case '3gp':case '3g2':case 'ogv':case 'webm':
       $this->type=noDivxVideo::init($this->previewImage,$this->width,$this->height);
       break;
     default:
       $this->type=divxVideo::init($this->previewImage,$this->width,$this->height);
     }
    }
    $this->id=$id;
    $this->file=$file;
    return $this;
  }

  public function display() {   return $this->type->display($this->id,$this->file); }
  public function load() { return $this->type->load($this->id,$this->file,$this->width,$this->height); }
  public function getScript() { return $this->type->getScript() ; }
}

//interface for building plugins
interface videoType {
  public static function init($previewImage,$width=false,$height=false); 
  public function display($id='',$video='',$width=false,$height=false);
  public function getScript();
  public function load($id='',$video='',$width=false,$height=false);
}

//plugin which implements divx video player
class divxVideo implements videoType {
  protected static $_that = null;
  protected $previewImage = null;
  protected $width = false;
  protected $height = false;
  protected $scriptloaded = false;

  protected function __construct($previewImage=false,$width=false,$height=false) {  
    if($previewImage)$this->previewImage=$previewImage;
    if($width)$this->width=$width;
    if($height)$this->height=$height;
    return $this;
  }
  
  public static function init($previewImage,$width=false,$height=false) {
    if(null==self::$_that)self::$_that = new self($previewImage,$width,$height);
    return self::$_that;
  }

  public function display($id='',$video='',$width=false,$height=false) {   
    if(!$width)$width=$this->width;
    if(!$height)$height=$this->height;
    return '<object classid="clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616" width="'.$width.'" height="'.$height.'" codebase="http://go.divx.com/plugin/DivXBrowserPlugin.cab">
        <param name="custommode" value="none" />
        <param name="previewImage" value="'.$this->previewImage.'" />
        <param name="autoPlay" value="false" />
        <param name="src" value="'.$video.'" />
        <embed type="video/divx" src="'.$video.'" custommode="none" width="'.$width.'" height="'.$height.'" autoPlay="false"  previewImage="'.$this->previewImage.'"  pluginspage="http://go.divx.com/plugin/download/"></embed></object>';
    
}

  public function getScript() { return ""; }
  public function load($id='',$video='',$width=false,$height=false) {    return "";   }
}

//plagin which implements jwplayer
class noDivxVideo implements videoType {
  protected static $_that = null;
  protected $width = false;
  protected $height = false;
  
  protected function __construct($width=false, $height=false) {  
    if($width)$this->width=$width;
    if($height)$this->height=$height;
    return $this;
  }
  
  public static function init($previewImage, $width=false, $height=false) {
    if(null==self::$_that)self::$_that = new self();
    return self::$_that;
  }

  public function display($id='',$video='',$width=false,$height=false) {   return '<div id="'.$id.'"></div>';  }

  public function getScript() {
    if(!$this->loadedScript) {
      $this->loadedScript=true;
      return '<script type="text/javascript" src="/jwplayer/jwplayer.js"></script>';
    }
    return '';
  }

  public function load($id='',$video='',$width=false, $height=false) {
    if(!$width)$width=$this->width;
    if(!$height)$height=$this->height;
    return '
    jwplayer("'.$id.'").setup({
      "flashplayer": "/jwplayer/player.swf",
	  "file": "'.$video.'",
	  "controlbar": "bottom",
	  "width": "'.$width.'",
	  "height": "'.$height.'"
    });';
  }
}

?>