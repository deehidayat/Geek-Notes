Copyright Virgilio Lino 2011 w3v. virgiliolino@gmail.com
It's a videplayer interface to use on web. Basing upon the file format, it loads one player,
you may buil simply a new plugin to recognize new fileformats.

The class is released under dual license,
Creative Commons Attribution 3.0 License and gpl license 2.

w3v 0.1 - Help wanted: i need to test the fileformats, i need free videos.
In the package there is the incredible fwplayer, copyright by them.
usage:

A videoplayer interface which creates a videoplayer or another basing upon file format
you may create your videoplayer plugin, which is just a class that must implements the videoType interface
fileformats it should recognize:
plugin noDivxVideo: it's implemented using jwplayer(its just for non commercial use) if you find something
really opensource and free please contact me. 
formats recognized:mp4,mov,f4v,flv,3gp,3g2,ogv,webm, you tube videos
plugin  divxVideo: it's implemented using divx webplayer
formats recognized:the others



How to use:


to load a video, indipendently the format:
<?php  require_once('includes/classes/w3v.php'); ?>

for every video:
<?php $w3v=new w3v('id of the div containing the video','file with full path'); ?>

For non experts you must use one new variable for every video, and one unique div id

<?php $w3v1=new w3v('id of new div','new file');?>
and so on

then in the body, where you want to see the video for every video, just write:
<?php $w3v->display(); ?>


Finally, you must load the javascript(where applied),  we recommend in the footer, inside a script tag:
<script type="text/javascript">
<?=$w3v->getScript();?>
<!-- once again, it must be done for every video <?=$w3v1->getScript();?> 
</script>
