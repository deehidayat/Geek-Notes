<script src="http://platform.twitter.com/anywhere.js?id=<?php echo $apiKey ?>&v=<?php echo $version ?>" type="text/javascript"></script>
