This document details all changes between different versions of FOSTwitterBundle:

1.1
---

- made user creation explicit by introducing a UserManagerInterface (this allows
  to create a user object if someone logs in through Twitter for the first time)

1.0
---

Initial release
