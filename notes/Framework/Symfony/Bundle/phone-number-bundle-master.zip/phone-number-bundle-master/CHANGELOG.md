Changelog
=========

1.0.0
-----

10 October 2013.

* Initial release.
