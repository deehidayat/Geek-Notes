Exclusion Strategies
====================

This document was moved to the standalone library, please see
`<http://jmsyst.com/libs/serializer/master/cookbook/exclusion_strategies>`_.
