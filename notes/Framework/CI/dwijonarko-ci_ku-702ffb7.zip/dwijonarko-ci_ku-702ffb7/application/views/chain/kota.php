Kota / Kabupaten :<br/>
   	<?php
    	echo form_dropdown("kota_id",$option_kota,'',"id='kota_id'");
    ?>
