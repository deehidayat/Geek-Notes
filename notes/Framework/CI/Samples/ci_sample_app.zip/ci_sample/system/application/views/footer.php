  </div>
</div>
<p id="footer">This demo application and tutorial built by <a href="http://www.derekallard.com">Derek Allard</a> <br />
  <a href="http://www.codeigniter.com">Code Igniter</a> copyright &copy; 2006 by <a href="http://www.pmachine.com">pMachine, Inc.</a>
</p>
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-316888-4";
urchinTracker();
</script>
</body>
</html>