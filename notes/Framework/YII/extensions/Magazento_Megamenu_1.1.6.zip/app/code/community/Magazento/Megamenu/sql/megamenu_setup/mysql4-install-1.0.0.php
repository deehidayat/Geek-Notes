<?php
/*
 *  Created on Mar 16, 2011
 *  Author Ivan Proskuryakov - volgodark@gmail.com - Magazento.com
 *  Copyright Proskuryakov Ivan. Magazento.com © 2011. All Rights Reserved.
 *  Single Use, Limited Licence and Single Use No Resale Licence ["Single Use"]
 */
?>
<?php

$installer = $this;
$installer->startSetup();
$installer->run("

CREATE TABLE IF NOT EXISTS `{$this->getTable('magazento_megamenu_category')}` (
  `category_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `catalog_id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `url` text NOT NULL,
  `column` tinyint(4) NOT NULL DEFAULT '2',
  `position` tinyint(4) NOT NULL DEFAULT '0',
  `align_category` varchar(10) NOT NULL DEFAULT 'left',
  `align_content` varchar(10) NOT NULL DEFAULT 'right',
  `content_top` text CHARACTER SET utf8 COLLATE utf8_bin,
  `content_bottom` text CHARACTER SET utf8 COLLATE utf8_bin,
  `from_time` datetime DEFAULT NULL,
  `to_time` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

INSERT INTO `{$this->getTable('magazento_megamenu_category')}` (`category_id`, `catalog_id`, `title`, `url`, `column`, `position`, `align_category`, `align_content`, `content_top`, `content_bottom`, `from_time`, `to_time`, `is_active`) VALUES
(2, 13, 'Electronics', '#', 2, 5, 'left', 'left', 0x3c68323e3220636f6c756d6e732063617465676f7279206c61796f75743c2f68323e0d0a3c703e596f752063616e20636f6d706c6574656c79206368616e6765206d656e75206f7220796f752063616e206c656176652069742061732069732c2074686973206d656e7520646f6573206e6f74206769766520796f7520616e792074726f75626c652e20416c6c207061727473206f66204d6567614d656e752061726520636f6d706c6574656c79206368616e676561626c6520696e207468652061646d696e6973747261746976652073656374696f6e2c20796f752063616e20616c736f206368616e6765206e616d6573206f722075726c206c696e6b732e2054686973206d656e75206973207265616c6c7920636f6e76696e69656e742e3c2f703e, '', '2009-11-06 10:46:36', '2011-03-12 02:45:00', 1),
(5, 10, 'Furniture', '#', 2, 2, 'left', 'left', 0x3c64697620636c6173733d22636f6c5f32223e0d0a3c68323e3220636f6c756d6e732063617465676f727920636f6e74656e743c2f68323e0d0a3c2f6469763e, '', '2011-02-27 16:47:02', NULL, 1),
(6, 18, 'Apparel', '#', 1, 12, 'left', 'left', 0x3c68323e3120436f6c756d6e3c2f68323e, 0x3c703e4353533320616e642043726f73732042726f7773657220537570706f72742e3c2f703e, '2001-03-12 16:52:09', '2016-03-31 16:52:09', 1),
(7, 3, 'Root', '/', 3, 1, 'left', 'left', '', 0x3c64697620636c6173733d22636f6c5f33223e0d0a3c68323e5468697320697320616e206578616d706c65206f662020726f6f742077697468203320636f6c756d6e733c2f68323e0d0a3c2f6469763e0d0a3c64697620636c6173733d22636f6c5f31223e0d0a3c7020636c6173733d22626c61636b5f626f78223e43726561742065646966666572656e7420636f6e74656e7420626c6c6f636b7320616e6420646973706c6179207468656d207769746820796f7520435353207374796c65733c2f703e0d0a3c2f6469763e0d0a3c64697620636c6173733d22636f6c5f31223e0d0a3c703e4372656174652062656175746966756c20626c6f636b732077697468206d6167656e746f2d667269656e646c7920696e74657266616365203c7374726f6e673e6174206261636b656e643c2f7374726f6e673e3c2f703e0d0a3c2f6469763e0d0a3c64697620636c6173733d22636f6c5f31223e3c696d67207372633d222f6d656469612f6d6167617a656e746f5f6d6567616d656e752f626573745f73656c6c696e675f696d6730322e706e672220616c743d22222077696474683d22393522206865696768743d22393522202f3e3c2f6469763e0d0a3c64697620636c6173733d22636f6c5f33223e456173696c79206368616e676520746f70206f7220626f74746f6d20636f6e74656e7420696e204d6567614d656e75206261636b656e642063617465676f72792073656374696f6e3c2f6469763e, '2011-03-13 23:18:23', NULL, 1);


-- --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `{$this->getTable('magazento_megamenu_category_store')}` (
  `category_id` smallint(6) unsigned DEFAULT NULL,
  `store_id` smallint(6) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `{$this->getTable('magazento_megamenu_category_store')}` (`category_id`, `store_id`) VALUES
(2, 0),
(5, 0),
(6, 0),
(7, 0);


-- --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `{$this->getTable('magazento_megamenu_item')}` (
  `item_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `column` tinyint(4) NOT NULL DEFAULT '2',
  `align_item` varchar(10) NOT NULL DEFAULT 'left',
  `align_content` varchar(10) NOT NULL DEFAULT 'right',
  `position` tinyint(10) NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `from_time` datetime DEFAULT NULL,
  `to_time` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `columnsize` tinyint(4) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

INSERT INTO {$this->getTable('magazento_megamenu_item')} (`item_id`, `title`, `url`, `column`, `align_item`, `align_content`, `position`, `content`, `from_time`, `to_time`, `is_active`, `columnsize`) VALUES
(11, '1 columns', '#', 1, 'right', 'right', 1, '<p><strong>Magento</strong>&nbsp;is an&nbsp;<a title=\"Open source\" href=\"http://en.wikipedia.org/wiki/Open_source\">open source</a>&nbsp;based&nbsp;<a class=\"mw-redirect\" title=\"Ecommerce\" href=\"http://en.wikipedia.org/wiki/Ecommerce\">ecommerce</a>&nbsp;web application that was launched on March 31, 2008. It was developed by Varien (now Magento Inc) with help from the programmers within the open source community but is owned solely by&nbsp;<a class=\"external text\" rel=\"nofollow\" href=\"http://www.magentocommerce.com/\">Magento Inc.</a>. Magento was built using the&nbsp;<a title=\"Zend Framework\" href=\"http://en.wikipedia.org/wiki/Zend_Framework\">Zend Framework</a>.&nbsp;It uses the&nbsp;<a title=\"Entity-attribute-value model\" href=\"http://en.wikipedia.org/wiki/Entity-attribute-value_model\">Entity-attribute-value</a>&nbsp;(EAV) database model to store data. The Magento Community Edition is the only free version of Magento available. All other versions of Magento are not free.</p>', '2011-09-23 22:14:44', NULL, 1, 0),
(12, '2 columns', '#', 2, 'right', 'right', 1, '<p><strong>Magento</strong>&nbsp;is an&nbsp;<a title=\"Open source\" href=\"http://en.wikipedia.org/wiki/Open_source\">open source</a>&nbsp;based&nbsp;<a class=\"mw-redirect\" title=\"Ecommerce\" href=\"http://en.wikipedia.org/wiki/Ecommerce\">ecommerce</a>&nbsp;web application that was launched on March 31, 2008. It was developed by Varien (now Magento Inc) with help from the programmers within the open source community but is owned solely by&nbsp;<a class=\"external text\" rel=\"nofollow\" href=\"http://www.magentocommerce.com/\">Magento Inc.</a>. Magento was built using the&nbsp;<a title=\"Zend Framework\" href=\"http://en.wikipedia.org/wiki/Zend_Framework\">Zend Framework</a>.&nbsp;It uses the&nbsp;<a title=\"Entity-attribute-value model\" href=\"http://en.wikipedia.org/wiki/Entity-attribute-value_model\">Entity-attribute-value</a>&nbsp;(EAV) database model to store data. The Magento Community Edition is the only free version of Magento available. All other versions of Magento are not free.</p>', '2011-09-23 22:14:44', NULL, 1, 0),
(13, '3 columns', '#', 3, 'right', 'right', 1, '<p><strong>Magento</strong>&nbsp;is an&nbsp;<a title=\"Open source\" href=\"http://en.wikipedia.org/wiki/Open_source\">open source</a>&nbsp;based&nbsp;<a class=\"mw-redirect\" title=\"Ecommerce\" href=\"http://en.wikipedia.org/wiki/Ecommerce\">ecommerce</a>&nbsp;web application that was launched on March 31, 2008. It was developed by Varien (now Magento Inc) with help from the programmers within the open source community but is owned solely by&nbsp;<a class=\"external text\" rel=\"nofollow\" href=\"http://www.magentocommerce.com/\">Magento Inc.</a>. Magento was built using the&nbsp;<a title=\"Zend Framework\" href=\"http://en.wikipedia.org/wiki/Zend_Framework\">Zend Framework</a>.&nbsp;It uses the&nbsp;<a title=\"Entity-attribute-value model\" href=\"http://en.wikipedia.org/wiki/Entity-attribute-value_model\">Entity-attribute-value</a>&nbsp;(EAV) database model to store data. The Magento Community Edition is the only free version of Magento available. All other versions of Magento are not free.</p>', '2011-09-23 22:14:44', NULL, 1, 0),
(14, '4 columns', '#', 4, 'right', 'right', 1, '<p><strong>Magento</strong>&nbsp;is an&nbsp;<a title=\"Open source\" href=\"http://en.wikipedia.org/wiki/Open_source\">open source</a>&nbsp;based&nbsp;<a class=\"mw-redirect\" title=\"Ecommerce\" href=\"http://en.wikipedia.org/wiki/Ecommerce\">ecommerce</a>&nbsp;web application that was launched on March 31, 2008. It was developed by Varien (now Magento Inc) with help from the programmers within the open source community but is owned solely by&nbsp;<a class=\"external text\" rel=\"nofollow\" href=\"http://www.magentocommerce.com/\">Magento Inc.</a>. Magento was built using the&nbsp;<a title=\"Zend Framework\" href=\"http://en.wikipedia.org/wiki/Zend_Framework\">Zend Framework</a>.&nbsp;It uses the&nbsp;<a title=\"Entity-attribute-value model\" href=\"http://en.wikipedia.org/wiki/Entity-attribute-value_model\">Entity-attribute-value</a>&nbsp;(EAV) database model to store data. The Magento Community Edition is the only free version of Magento available. All other versions of Magento are not free.</p>', '2011-09-23 22:14:44', NULL, 1, 0),
(15, '5 columns', '#', 5, 'right', 'right', 1, '<p><strong>Magento</strong>&nbsp;is an&nbsp;<a title=\"Open source\" href=\"http://en.wikipedia.org/wiki/Open_source\">open source</a>&nbsp;based&nbsp;<a class=\"mw-redirect\" title=\"Ecommerce\" href=\"http://en.wikipedia.org/wiki/Ecommerce\">ecommerce</a>&nbsp;web application that was launched on March 31, 2008. It was developed by Varien (now Magento Inc) with help from the programmers within the open source community but is owned solely by&nbsp;<a class=\"external text\" rel=\"nofollow\" href=\"http://www.magentocommerce.com/\">Magento Inc.</a>. Magento was built using the&nbsp;<a title=\"Zend Framework\" href=\"http://en.wikipedia.org/wiki/Zend_Framework\">Zend Framework</a>.&nbsp;It uses the&nbsp;<a title=\"Entity-attribute-value model\" href=\"http://en.wikipedia.org/wiki/Entity-attribute-value_model\">Entity-attribute-value</a>&nbsp;(EAV) database model to store data. The Magento Community Edition is the only free version of Magento available. All other versions of Magento are not free.</p>', '2011-09-23 22:14:44', NULL, 1, 0),
(16, 'Megamenu sameple item left', '#', 2, 'left', 'left', 1, '<p><strong>Magento</strong>&nbsp;is an&nbsp;<a title=\"Open source\" href=\"http://en.wikipedia.org/wiki/Open_source\">open source</a>&nbsp;based&nbsp;<a class=\"mw-redirect\" title=\"Ecommerce\" href=\"http://en.wikipedia.org/wiki/Ecommerce\">ecommerce</a>&nbsp;web application that was launched on March 31, 2008. It was developed by Varien (now Magento Inc) with help from the programmers within the open source community but is owned solely by&nbsp;<a class=\"external text\" rel=\"nofollow\" href=\"http://www.magentocommerce.com/\">Magento Inc.</a>. Magento was built using the&nbsp;<a title=\"Zend Framework\" href=\"http://en.wikipedia.org/wiki/Zend_Framework\">Zend Framework</a>.&nbsp;It uses the&nbsp;<a title=\"Entity-attribute-value model\" href=\"http://en.wikipedia.org/wiki/Entity-attribute-value_model\">Entity-attribute-value</a>&nbsp;(EAV) database model to store data. The Magento Community Edition is the only free version of Magento available. All other versions of Magento are not free.</p>', '2011-09-23 22:14:44', NULL, 1, 0);

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `{$this->getTable('magazento_megamenu_item_store')}` (
  `item_id` smallint(6) unsigned DEFAULT NULL,
  `store_id` smallint(6) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO {$this->getTable('magazento_megamenu_item_store')} (`item_id`, `store_id`) VALUES
(11, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0);

");

$installer->endSetup();
?>