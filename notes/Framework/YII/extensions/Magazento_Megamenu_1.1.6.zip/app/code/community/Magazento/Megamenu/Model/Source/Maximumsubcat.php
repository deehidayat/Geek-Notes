<?php
/*
 *  Created on Mar 16, 2011
 *  Author Ivan Proskuryakov - volgodark@gmail.com - Magazento.com
 *  Copyright Proskuryakov Ivan. Magazento.com © 2011. All Rights Reserved.
 *  Single Use, Limited Licence and Single Use No Resale Licence ["Single Use"]
 */
?>
<?php

class Magazento_Megamenu_Model_Source_Maximumsubcat {

    public function toOptionArray() {
        return array(
            array('value' => 5, 'label' => 5),
            array('value' => 6, 'label' => 6),
            array('value' => 7, 'label' => 7),
            array('value' => 8, 'label' => 8),
            array('value' => 9, 'label' => 9),
            array('value' => 10, 'label' => 10),
            array('value' => 11, 'label' => 11),
            array('value' => 12, 'label' => 12),
            array('value' => 13, 'label' => 13),
            array('value' => 14, 'label' => 14),
            array('value' => 15, 'label' => 15),
            array('value' => 16, 'label' => 16),
            array('value' => 17, 'label' => 17),
            array('value' => 18, 'label' => 18),
            array('value' => 19, 'label' => 19),
            array('value' => 20, 'label' => 20),
        );
    }

}