<?php
return array(
	'The record was added' => 'Запись добавлена',
	'The record was not added' => 'Запись не была добавлена',
	'The record has been changed' => 'Запись изменена',
	'The record has not been changed' => 'Запись не изменилась',
	'The record was deleted' => 'Запись удалена',
	'The record has not been deleted' => 'Запись не была удалена',
	'The record will be deleted' => 'Запись будет удалена',
);
