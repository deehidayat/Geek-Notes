<?php
return array(
	'SQL table name' => 'Имя SQL-таблицы',
	'Columns' => 'Поля',
	'Table has not been selected' => 'Таблица не была выбрана',
	'Incorrect table "{table}"' => 'Некорректная таблица {table}',
	'SQL table selection' => 'Выбор SQL таблицы',
	'AutoAdmin Generator' => 'AutoAdmin генератор',
	'Creation interface for the table "{table}"' => 'Создание интерфейса для таблицы "{table}"',
	'Copy the text above and past it into your controller\'s code.' => 'Скопируйте вышестоящий текст и вставьте его в необходимый контроллер.',
);