<?php
/**
 * AutoAdmin exceptions processor.
 *
 * @author Alexander Palamarchuk <a@palamarchuk.info>
 */
class AAException extends CException
{
	
}
