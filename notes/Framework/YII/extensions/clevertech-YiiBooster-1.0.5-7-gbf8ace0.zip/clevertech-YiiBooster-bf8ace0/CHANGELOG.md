# ChangeLog
## Special Thanks
I would like to personally thank everyone of you that spend your valuable time helping improving this extension, by pointing out bugs and/or providing solutions that all of us can take advantage with. 

Thank you all

Antonio Ramirez  
Senior Web Developer  
[www.clevertech.biz](http://www.clevertech.biz)

### YiiBooster version 1.0.5 

- **(fix)** TbCarousel displayPrevAndNext set to false breaks the page (amosviedo)
- **(enhancement)** Bootstrap upgrade to 2.2.1 (kazuo)
- **(fix)** TbActiveForm class name is displayed on screen (sorinpohontu)
- **(fix)** TbExtendedGridView Bulk Actions Bug (antonio ramirez)
- **(enhancement)** Updated jquery-ui LESS (kazuo)
- **(enhancement)** Bootbox now can be activated/deactived at will (antonio ramirez) 
- **(enhancement)** Added TbExtendedGridFilter widget (antonio ramirez)
- **(enhancement)** Added JSONStorage component (antonio ramirez)
- **(fix)** Overrided TbBox bug by upgrade (ragazzo)
- **(enhancement)** Now TbBox can hold multiple types of buttons (dragnet)
- **(enhancement)** Added bootstrap styles to TbSelect2 widget (DonFelipe)
- **(enhancement)** Added radioButton group list support (xpoft)
- **(fix)** Hungarian translation corrected (pappfer)
- **(fix)** renderKeys() in TbExtendedGridView generates invalid html (TrueTamTam)
- **(fix)** TbFileUpload - bug in global progressbar (appenshin)
- **(enhancement)** Added support to TbActiveForm to use TbSelect2 widget (antonio ramirez)
- **(enhancement)** Added MarkDown Editor (kazuo)