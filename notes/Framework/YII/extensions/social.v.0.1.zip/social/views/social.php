
<div class="social clearfix">
	<?php echo $rendered;?>
</div>





