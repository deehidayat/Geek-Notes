<?php

/**
 * This is the model class for table "participant".
 *
 * The followings are the available columns in table 'participant':
 * @property integer $idparticipant
 * @property string $name_participant
 * @property string $nip
 * @property string $city
 * @property integer $trainingid
 *
 * The followings are the available model relations:
 * @property Training $training
 */
class Participant extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return Participant the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'participant';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('trainingid', 'required'),
			array('trainingid', 'numerical', 'integerOnly'=>true),
			array('name_participant, city', 'length', 'max'=>45),
			array('nip', 'length', 'max'=>18),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('idparticipant, name_participant, nip, city, trainingid', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'training' => array(self::BELONGS_TO, 'Training', 'trainingid'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'idparticipant' => 'Idparticipant',
			'name_participant' => 'Name Participant',
			'nip' => 'Nip',
			'city' => 'City',
			'trainingid' => 'Trainingid',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('idparticipant',$this->idparticipant);
		$criteria->compare('name_participant',$this->name_participant,true);
		$criteria->compare('nip',$this->nip,true);
		$criteria->compare('city',$this->city,true);
		$criteria->compare('trainingid',$this->trainingid);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}