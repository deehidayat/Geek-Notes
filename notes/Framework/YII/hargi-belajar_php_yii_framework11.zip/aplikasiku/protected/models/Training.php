<?php

/**
 * This is the model class for table "training".
 *
 * The followings are the available columns in table 'training':
 * @property integer $idtraining
 * @property string $name_training
 * @property string $hours
 * @property string $time_start
 * @property string $time_end
 * @property integer $categoryid
 *
 * The followings are the available model relations:
 * @property Participant[] $participants
 * @property Category $category
 */
class Training extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return Training the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'training';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('categoryid', 'required'),
			array('categoryid', 'numerical', 'integerOnly'=>true),
			array('name_training, hours', 'length', 'max'=>45),
			array('time_start, time_end', 'safe'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('idtraining, name_training, hours, time_start, time_end, categoryid', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'participants' => array(self::HAS_MANY, 'Participant', 'trainingid'),
			'category' => array(self::BELONGS_TO, 'Category', 'categoryid'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'idtraining' => 'Idtraining',
			'name_training' => 'Name Training',
			'hours' => 'Hours',
			'time_start' => 'Time Start',
			'time_end' => 'Time End',
			'categoryid' => 'Categoryid',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('idtraining',$this->idtraining);
		$criteria->compare('name_training',$this->name_training,true);
		$criteria->compare('hours',$this->hours,true);
		$criteria->compare('time_start',$this->time_start,true);
		$criteria->compare('time_end',$this->time_end,true);
		$criteria->compare('categoryid',$this->categoryid);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}