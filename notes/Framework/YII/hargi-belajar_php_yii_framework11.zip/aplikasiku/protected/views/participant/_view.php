<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('idparticipant')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->idparticipant), array('view', 'id'=>$data->idparticipant)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('name_participant')); ?>:</b>
	<?php echo CHtml::encode($data->name_participant); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nip')); ?>:</b>
	<?php echo CHtml::encode($data->nip); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('city')); ?>:</b>
	<?php echo CHtml::encode($data->city); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('trainingid')); ?>:</b>
	<?php echo CHtml::encode($data->trainingid); ?>
	<br />


</div>