<?php
$this->breadcrumbs=array(
	'Participants'=>array('index'),
	$model->name_participant,
);


$this->menu=array(
	array('label'=>'Ubah Peserta', 'url'=>array('update', 'id'=>$model->idparticipant)),
	array('label'=>'Hapus Peserta', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->idparticipant),'confirm'=>'Are you sure you want to delete this item?')),
);

?>

<h1><?php echo $model->name_participant; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'name_participant',
		'nip',
		'city',
			),
)); ?>

