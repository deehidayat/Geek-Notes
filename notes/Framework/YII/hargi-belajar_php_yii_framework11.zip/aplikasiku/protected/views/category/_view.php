<div class="view">

	<h2><?php echo CHtml::link(CHtml::encode($data->category_name), array('view', 'id'=>$data->idcategory)); ?></h2>

</div>