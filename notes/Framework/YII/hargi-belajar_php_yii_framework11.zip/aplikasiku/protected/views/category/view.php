<?php
$this->breadcrumbs=array(
	'Categories'=>array('index'),
	$model->category_name,
);?>
<?php
$this->menu=array(
	array('label'=>'Tambah Diklat Baru', 'url'=>array('training/create','id'=>$model->idcategory )),);
?>
<?php $this->widget('zii.widgets.grid.CGridView', array( 
    'id'=>'training-grid', 
    'dataProvider'=>$totraining->search(), 
    //'filter'=>$totraining, 
    'emptyText'=>'Belum ada training pada kategori ini', 
    'summaryText'=>'', 
    'columns'=>array( 
        array( 
            'name'=>'No',
			 'type'=>'raw', 
            'value'=>'$data->idtraining', 
        ),
		array( 
            'name'=>'Nama diklat',
			 'type'=>'raw', 
            'value'=>'Chtml::link($data->name_training,array(\'training/view\',\'id\'=>$data->idtraining))', 
        ),
		array( 
            'name'=>'Jamlat',
			 'type'=>'raw', 
            'value'=>'$data->hours', 
        ),
		)));?>
