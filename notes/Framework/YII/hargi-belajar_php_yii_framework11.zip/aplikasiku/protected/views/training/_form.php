<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'training-form',
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'name_training'); ?>
		<?php echo $form->textField($model,'name_training',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'name_training'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'hours'); ?>
		<?php echo $form->textField($model,'hours',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'hours'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'time_start'); ?>
		<?php echo $form->textField($model,'time_start'); ?>
		<?php echo $form->error($model,'time_start'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'time_end'); ?>
		<?php echo $form->textField($model,'time_end'); ?>
		<?php echo $form->error($model,'time_end'); ?>
	</div>

	<div class="row">
		<?php //echo $form->labelEx($model,'categoryid'); ?>
		<?php //echo $form->textField($model,'categoryid'); ?>
		<?php //echo $form->error($model,'categoryid'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->