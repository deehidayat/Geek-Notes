<?php
$this->breadcrumbs=array(
	'Trainings'=>array('index'),
	$model->idtraining=>array('view','id'=>$model->idtraining),
	'Update',
);

$this->menu=array(
	array('label'=>'List Training', 'url'=>array('index')),
	array('label'=>'Create Training', 'url'=>array('create')),
	array('label'=>'View Training', 'url'=>array('view', 'id'=>$model->idtraining)),
	array('label'=>'Manage Training', 'url'=>array('admin')),
);
?>

<h1>Update Training <?php echo $model->idtraining; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>