<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'idtraining'); ?>
		<?php echo $form->textField($model,'idtraining'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'name_training'); ?>
		<?php echo $form->textField($model,'name_training',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'hours'); ?>
		<?php echo $form->textField($model,'hours',array('size'=>45,'maxlength'=>45)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'time_start'); ?>
		<?php echo $form->textField($model,'time_start'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'time_end'); ?>
		<?php echo $form->textField($model,'time_end'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'categoryid'); ?>
		<?php echo $form->textField($model,'categoryid'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->