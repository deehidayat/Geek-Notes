<?php
$this->breadcrumbs=array(
	'Categories'=>array('index'),
	$model->name_training,
); ?>
<?php
$this->menu=array(
	array('label'=>'Daftarkan Peserta', 'url'=>array('participant/create','id'=>$model->idtraining )),);
?>
<?php $this->widget('zii.widgets.grid.CGridView', array( 
    'id'=>'participant-grid', 
    'dataProvider'=>$toparticipant->search(), 
    //'filter'=>$toparticipant, 
    'emptyText'=>'Belum ada Peserta yang mendaftar pada diklat ini',
    'summaryText'=>'', 
    'columns'=>array( 
        array( 
            'name'=>'No',
			 'type'=>'raw', 
            'value'=>'$data->idparticipant', 
        ),
		array( 
            'name'=>'Nama Peserta',
			 'type'=>'raw', 
            'value'=>'Chtml::link($data->name_participant,array(\'participant/view\',\'id\'=>$data->idparticipant))', 
        ),
		array( 
            'name'=>'Jamlat',
			 'type'=>'raw', 
            'value'=>'$data->city', 
        ),
		)));?>
