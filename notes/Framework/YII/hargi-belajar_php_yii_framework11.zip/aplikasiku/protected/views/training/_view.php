<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('idtraining')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->idtraining), array('view', 'id'=>$data->idtraining)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('name_training')); ?>:</b>
	<?php echo CHtml::encode($data->name_training); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('hours')); ?>:</b>
	<?php echo CHtml::encode($data->hours); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('time_start')); ?>:</b>
	<?php echo CHtml::encode($data->time_start); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('time_end')); ?>:</b>
	<?php echo CHtml::encode($data->time_end); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('categoryid')); ?>:</b>
	<?php echo CHtml::encode($data->categoryid); ?>
	<br />


</div>